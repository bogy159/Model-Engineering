/**
 */
package roverml;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Regular</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roverml.RovermlPackage#getRegular()
 * @model
 * @generated
 */
public interface Regular extends Transition {
} // Regular
