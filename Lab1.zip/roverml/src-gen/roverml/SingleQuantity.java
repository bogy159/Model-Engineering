/**
 */
package roverml;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Single Quantity</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roverml.RovermlPackage#getSingleQuantity()
 * @model
 * @generated
 */
public interface SingleQuantity extends Quantity {
} // SingleQuantity
