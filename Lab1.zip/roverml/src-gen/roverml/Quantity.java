/**
 */
package roverml;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Quantity</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roverml.RovermlPackage#getQuantity()
 * @model
 * @generated
 */
public interface Quantity extends EObject {
} // Quantity
