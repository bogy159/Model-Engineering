/**
 */
package roverml;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Motor</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roverml.RovermlPackage#getMotor()
 * @model
 * @generated
 */
public interface Motor extends Actuator {
} // Motor
