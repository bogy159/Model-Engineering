/**
 */
package roverml;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Terminate</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roverml.RovermlPackage#getTerminate()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='noOutTransitions'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot noOutTransitions='self.outgoingTransitions -&gt; isEmpty()'"
 * @generated
 */
public interface Terminate extends Command {
} // Terminate
