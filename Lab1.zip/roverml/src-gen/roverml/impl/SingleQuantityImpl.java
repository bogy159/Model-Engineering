/**
 */
package roverml.impl;

import org.eclipse.emf.ecore.EClass;

import roverml.RovermlPackage;
import roverml.SingleQuantity;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Single Quantity</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class SingleQuantityImpl extends QuantityImpl implements SingleQuantity {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SingleQuantityImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RovermlPackage.Literals.SINGLE_QUANTITY;
	}

} //SingleQuantityImpl
