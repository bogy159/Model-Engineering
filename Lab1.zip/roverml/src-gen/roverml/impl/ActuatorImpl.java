/**
 */
package roverml.impl;

import org.eclipse.emf.ecore.EClass;

import roverml.Actuator;
import roverml.RovermlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Actuator</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class ActuatorImpl extends ComponentImpl implements Actuator {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ActuatorImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RovermlPackage.Literals.ACTUATOR;
	}

} //ActuatorImpl
