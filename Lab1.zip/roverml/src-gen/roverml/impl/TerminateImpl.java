/**
 */
package roverml.impl;

import org.eclipse.emf.ecore.EClass;

import roverml.RovermlPackage;
import roverml.Terminate;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Terminate</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class TerminateImpl extends CommandImpl implements Terminate {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TerminateImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return RovermlPackage.Literals.TERMINATE;
	}

} //TerminateImpl
