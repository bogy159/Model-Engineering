/**
 */
package roverml;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Actuator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see roverml.RovermlPackage#getActuator()
 * @model
 * @generated
 */
public interface Actuator extends Component {
} // Actuator
